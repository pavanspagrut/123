package com.demo;

public class Testarray2 {
	
	public static void main(String[] args) {
		int a[] = {10,20,30};
		
		String str[] = {"Ram", "Shyam"};
		
		/*for(int i=0; i<a.length;i++) {
			System.out.println(a[i]);
		}
		
		for(int i=0; i<str.length ; i++) {
			System.out.println(str[i].length());
		}*/
		
		for(String i : str) {
			System.out.println(i);
		}
		
		System.out.println(str[1]);
	}

}
