package com.demo;

public class TestStudent {
	
	public static void main(String[] args) {
		//declare array of Student
		Student[] arr;
		
		//allocating memory 
		arr = new Student[5];
		
		Student s1 = new Student(1, "Anil");
		
		arr[0]= s1 ;
		
		arr[1] = new Student(2, "Aditi");
		
		arr[2] = new Student(3, "Chitra");
		
		arr[3] = new Student(4,"Deepak");
		
		arr[4] = new Student(5,"Pratham");
		
		
		/*for(int index = 0 ; index < arr.length ;index++) {
			System.out.println(arr[index].rollNo+" "+arr[index].name);
		}
		*/
		for(Student s : arr) {
			System.out.println(s);
		}
		
		
		
		
	}

}
